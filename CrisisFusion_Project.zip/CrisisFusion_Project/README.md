# CrisisFusion — Emergency Response Dashboard Prototype

## Included
- `app.py`: Streamlit dashboard with overview, EDA, flood monitoring, resource availability, priority queue and source-data tabs.
- `preprocess.py`: basic data cleaning for the incident CSV.
- `data/`: five **synthetic demonstration CSV files** (incidents, resources, flood readings, SOS reports and agencies).

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create/activate a virtual environment (recommended).
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the dashboard:
   ```bash
   streamlit run app.py
   ```

## Data note
The included records are synthetic sample data created to demonstrate the project workflow. They are not official emergency reports, sensor feeds, or evidence of live operation. Replace the CSV files in `data/` with your team's verified datasets, keeping the column names consistent.

## Important implementation boundary
This package provides data cleaning, exploratory analysis, interactive visualizations and a transparent severity-based priority queue. It does **not** include a trained AI/ML model, automatic dispatch, live ESP32/HC-SR04 connection, GPS vehicle tracking, or live agency integrations. Those require actual implementation, hardware/API credentials, testing and human authorization before operational use.

## Suggested review flow
Raw CSVs → `preprocess.py` → Streamlit dashboard → EDA charts → rule-based priority queue → human decision support.
