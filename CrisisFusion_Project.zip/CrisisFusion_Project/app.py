import os
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="CrisisFusion", page_icon="🚨", layout="wide")
st.title("🚨 CrisisFusion")
st.caption("AI-assisted emergency resource allocation — educational prototype")

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

@st.cache_data
def load_data():
    files = {
        "incidents": "incidents.csv",
        "resources": "resources.csv",
        "flood": "flood_readings.csv",
        "sos": "sos_reports.csv",
        "agencies": "agencies.csv",
    }
    result = {}
    for key, filename in files.items():
        path = os.path.join(DATA_DIR, filename)
        result[key] = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame()
    return result

def clean_incidents(df):
    if df.empty:
        return df
    df = df.copy()
    df.columns = df.columns.str.strip().str.lower()
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].astype("string").str.strip()
    if "timestamp" in df:
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    for col in ["latitude", "longitude"]:
        if col in df:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.drop_duplicates()
    if "severity" in df:
        df["severity"] = df["severity"].str.title()
    return df

data = load_data()
incidents = clean_incidents(data["incidents"])
resources = data["resources"].copy()
flood = data["flood"].copy()
sos = data["sos"].copy()
agencies = data["agencies"].copy()

with st.sidebar:
    st.header("Filters")
    severity_options = sorted(incidents["severity"].dropna().unique().tolist()) if not incidents.empty else []
    selected_severity = st.multiselect("Incident severity", severity_options, default=severity_options)
    area_options = sorted(incidents["area"].dropna().unique().tolist()) if not incidents.empty else []
    selected_area = st.multiselect("Area", area_options, default=area_options)
    st.divider()
    st.caption("Demo data only. Replace CSV files in /data with verified project data.")

filtered = incidents.copy()
if selected_severity:
    filtered = filtered[filtered["severity"].isin(selected_severity)]
if selected_area:
    filtered = filtered[filtered["area"].isin(selected_area)]

total = len(filtered)
critical = int((filtered["severity"] == "Critical").sum()) if total else 0
open_count = int((filtered["status"] == "Open").sum()) if total else 0
units_available = int((pd.to_numeric(resources.get("total_quantity", pd.Series(dtype=float)), errors="coerce") -
                       pd.to_numeric(resources.get("allocated_quantity", pd.Series(dtype=float)), errors="coerce")).clip(lower=0).sum()) if not resources.empty else 0

c1,c2,c3,c4 = st.columns(4)
c1.metric("Incidents", total)
c2.metric("Critical incidents", critical)
c3.metric("Open incidents", open_count)
c4.metric("Unallocated resource units", units_available)

tab1, tab2, tab3, tab4, tab5 = st.tabs(["Overview","Incident analysis","Flood monitoring","Resources","Data tables"])

with tab1:
    st.subheader("Emergency situation overview")
    left,right = st.columns(2)
    if not filtered.empty:
        by_severity = filtered.groupby("severity", dropna=False).size().reset_index(name="count")
        left.plotly_chart(px.bar(by_severity, x="severity", y="count", title="Incidents by severity"), use_container_width=True)
        by_type = filtered.groupby("incident_type", dropna=False).size().reset_index(name="count")
        right.plotly_chart(px.pie(by_type, names="incident_type", values="count", title="Incidents by type"), use_container_width=True)
        if {"latitude","longitude"}.issubset(filtered.columns):
            st.plotly_chart(px.scatter_mapbox(filtered.dropna(subset=["latitude","longitude"]),
                lat="latitude", lon="longitude", color="severity", hover_name="incident_id",
                hover_data=["area","incident_type","status"], zoom=9,
                mapbox_style="open-street-map", title="Incident locations"), use_container_width=True)
    else:
        st.info("No incident records match the selected filters.")

with tab2:
    st.subheader("Exploratory data analysis")
    if not filtered.empty:
        a,b = st.columns(2)
        status = filtered.groupby("status").size().reset_index(name="count")
        a.plotly_chart(px.bar(status, x="status", y="count", title="Incidents by status"), use_container_width=True)
        area = filtered.groupby("area").size().reset_index(name="count").sort_values("count", ascending=False)
        b.plotly_chart(px.bar(area, x="area", y="count", title="Incidents by area"), use_container_width=True)
        st.write("Summary statistics")
        st.dataframe(filtered.describe(include="all").transpose(), use_container_width=True)

with tab3:
    st.subheader("Flood water-level monitoring")
    if not flood.empty:
        flood["timestamp"] = pd.to_datetime(flood["timestamp"], errors="coerce")
        flood["water_level_m"] = pd.to_numeric(flood["water_level_m"], errors="coerce")
        st.plotly_chart(px.line(flood.sort_values("timestamp"), x="timestamp", y="water_level_m",
                                color="area", markers=True, title="Water level over time (metres)"),
                        use_container_width=True)
        threshold = st.number_input("Illustrative alert threshold (metres)", min_value=0.1, value=1.5, step=0.1)
        latest = flood.sort_values("timestamp").groupby("area").tail(1)
        alerts = latest[latest["water_level_m"] >= threshold]
        if not alerts.empty:
            st.warning("Threshold reached in: " + ", ".join(alerts["area"].astype(str).tolist()))
        else:
            st.success("No area is above the selected illustrative threshold.")
    else:
        st.info("No flood readings found.")

with tab4:
    st.subheader("Resource availability and rule-based allocation")
    if not resources.empty:
        resources["available_quantity"] = (
            pd.to_numeric(resources["total_quantity"], errors="coerce").fillna(0) -
            pd.to_numeric(resources["allocated_quantity"], errors="coerce").fillna(0)
        ).clip(lower=0)
        st.dataframe(resources, use_container_width=True)
        st.plotly_chart(px.bar(resources, x="resource_type", y="available_quantity",
                               title="Available units by resource type"), use_container_width=True)
    st.markdown("#### Suggested priority queue")
    priority_rank = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}
    if not filtered.empty:
        queue = filtered.copy()
        queue["priority_rank"] = queue["severity"].map(priority_rank).fillna(4)
        queue = queue.sort_values(["priority_rank","timestamp"], ascending=[True, True])
        st.dataframe(queue[["incident_id","area","incident_type","severity","status","timestamp"]],
                     use_container_width=True)
        st.caption("This is a transparent rule-based demonstration, not a trained AI model or an automatic dispatch system.")
    if not agencies.empty:
        st.markdown("#### Participating agencies")
        st.dataframe(agencies, use_container_width=True)

with tab5:
    st.subheader("Source data")
    for label, frame in [("Incidents",incidents),("Resources",resources),("Flood readings",flood),
                         ("SOS reports",sos),("Agencies",agencies)]:
        with st.expander(label):
            st.dataframe(frame, use_container_width=True)

st.divider()
st.caption("CrisisFusion prototype • Use verified, authorized data and human approval for real emergency operations.")
