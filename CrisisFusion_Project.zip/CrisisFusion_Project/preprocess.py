import os
import pandas as pd

ROOT = os.path.dirname(__file__)
DATA = os.path.join(ROOT, "data")
OUT = os.path.join(DATA, "cleaned_incidents.csv")

df = pd.read_csv(os.path.join(DATA, "incidents.csv"))
df.columns = df.columns.str.strip().str.lower()
for col in df.select_dtypes(include="object").columns:
    df[col] = df[col].astype("string").str.strip()
df = df.drop_duplicates()
df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
for col in ["latitude", "longitude"]:
    df[col] = pd.to_numeric(df[col], errors="coerce")
df["severity"] = df["severity"].str.title()
df.to_csv(OUT, index=False)
print(f"Saved cleaned dataset: {OUT}")
print(df.info())
print(df.isna().sum())
